class AppError extends Error {
  constructor(message, statusCode, code = null, details = null) {
    super(message);
    this.statusCode = statusCode;
    this.code = code;
    this.details = details;
    this.isOperational = true;
    Error.captureStackTrace(this, this.constructor);
  }
}

function errorHandler(logger) {
  return (err, req, res, next) => {
    const requestId = req.id || 'unknown';

    let statusCode = err.statusCode || 500;
    let code = err.code || 'INTERNAL_ERROR';
    let message = err.message || 'Errore interno del server';
    let details = err.details || null;

    if (statusCode >= 500) {
      req.log.error({
        err,
        requestId,
        url: req.url,
        method: req.method,
        stack: err.stack
      }, 'Server error');
    }

    res.status(statusCode).json({
      success: false,
      error: {
        code,
        message,
        ...(details && { details }),
        requestId
      }
    });
  };
}

module.exports = {
  AppError,
  errorHandler
};
