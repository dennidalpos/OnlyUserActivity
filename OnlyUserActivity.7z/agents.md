# Agent Notes

This repository uses EJS templates for the admin UI, and configuration is driven via `.env`.
When adding new settings, ensure the admin settings page exposes the corresponding inputs
and the backend persists them through the settings service.
